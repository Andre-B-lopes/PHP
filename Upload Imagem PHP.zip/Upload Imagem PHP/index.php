<html>
<body>
<div class="modal-body">
<form action="upload.php" method="post" enctype="multipart/form-data">               
<label><i class="fas fa-camera fa-2x"></i><strong> Inserir foto:</strong></label><br>
<input type="file" name="nArquivo" id="iArquivo" class="mb-3">
<input type="submit">
</div>
</body>
</html>